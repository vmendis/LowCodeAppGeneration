./get-docker.sh
./get-docker-compose.sh
./docker_setup
